<<<<<<< HEAD
# micro-ROS-diff_drive_control ROS2 HUMBLE
controlador diferencial usando micro-ROS, lectura de codificadores de rueda y lectura de sensor imu GY-91 
=======
# Controlador diferencial con micro-ROS y ROS Humble

## Hardware/Software utilizado

- ESP32 DEVKIT V1
- Raspberry pi 4 model B
- L298N
- Motor DC (4) 

>>>>>>> 07ee82b (actualziacion de la libreria encoder)
