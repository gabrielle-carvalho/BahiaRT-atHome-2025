// Author: Yalmar Cardenas
// Date: 2022-12-15
// Drive a robot with 4 motors using PWM and a L298N motor driver board (Diff Drive Robot)
// Adaptação: Josemar / João
// Date: 2023-07-08
// Drive a robot with 4 motors using PWM and a two (2) L298N motor driver board (Diff Drive Robot)
#include "motor_driver.h"

#include <stdio.h>
#include <unistd.h>
#include <inttypes.h>
#include <math.h>
#include "rcl/time.h"
#include "esp_timer.h"
#include <driver/gpio.h>
#include <driver/ledc.h>

#include "driver/i2c.h"
#ifdef ESP_PLATFORM
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#endif

motor_setup_t motor_setup;

//Constants

/*
//zé
#define WHEEL_RADIUS 0.04
#define AXIS_DISTANCE 0.13
#define AXIS_LENGTH 0.17
*/


//mané
#define WHEEL_RADIUS 0.0325
#define AXIS_DISTANCE 0.275
#define AXIS_LENGTH 0.350

/*
//billestranho
#define WHEEL_RADIUS 0.070
#define AXIS_DISTANCE 0.365
#define AXIS_LENGTH 0.430
*/

//Function to initialize the motor driver
void InitMotorDriver(motor_setup_t motor_setup) {
    motor_setup = motor_setup;
    // Led. Set it to GPIO_MODE_INPUT_OUTPUT, because we want to read back the state we set it to.
    gpio_reset_pin(motor_setup.LED_BUILTIN);
    gpio_set_direction(motor_setup.LED_BUILTIN, GPIO_MODE_INPUT_OUTPUT); // Set the pin as output

    // Configure timer
    ledc_timer_config_t ledc_timer = {
        .duty_resolution = motor_setup.PWM_RESOLUTION,
        .freq_hz = motor_setup.PWM_FREQUENCY,
        .speed_mode = motor_setup.PWM_MODE,
        .timer_num = motor_setup.PWM_TIMER,
        .clk_cfg = LEDC_AUTO_CLK,
    };
    ledc_timer_config(&ledc_timer);

    // Configure 4 PWM channels and assign output pins // JS - 8
    ledc_channel_config_t ledc_channel[8] = {
        // Motor front - JS
        {
            .channel    = motor_setup.front_PWM_LEFT_FORWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.front_PIN_LEFT_FORWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.front_PWM_LEFT_BACKWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.front_PIN_LEFT_BACKWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.front_PWM_RIGHT_FORWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.front_PIN_RIGHT_FORWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.front_PWM_RIGHT_BACKWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.front_PIN_RIGHT_BACKWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        // Motor rear - JS
        {
            .channel    = motor_setup.rear_PWM_LEFT_FORWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.rear_PIN_LEFT_FORWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.rear_PWM_LEFT_BACKWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.rear_PIN_LEFT_BACKWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.rear_PWM_RIGHT_FORWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.rear_PIN_RIGHT_FORWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
        {
            .channel    = motor_setup.rear_PWM_RIGHT_BACKWARD,
            .duty       = 0,
            .gpio_num   = motor_setup.rear_PIN_RIGHT_BACKWARD,
            .speed_mode = motor_setup.PWM_MODE,
            .hpoint     = 0,
            .timer_sel  = LEDC_TIMER_1
        },
    };

    for (int i = 0; i < 8; i++) {
        ledc_channel_config(&ledc_channel[i]);
    }
}

// Set motor speed function (linear_x, linear_y and angular) from cmd_vel topic (geometry_msgs/Twist)
void SetMotorSpeed(float linear_x, float linear_y, float angular_z) {
    // Convert the linear_x, linear_y and angular_z speeds to front_left, rear_left, front_right and rear_right speeds
    float half_axis_separation = AXIS_DISTANCE / 2;
    float half_axis_length = AXIS_LENGTH / 2;
    
    float front_left_speed = (1 / WHEEL_RADIUS) * (linear_x - linear_y - (half_axis_separation+half_axis_length) * angular_z);
    float front_right_speed = (1 / WHEEL_RADIUS) * (linear_x + linear_y + (half_axis_separation+half_axis_length) * angular_z);
    float rear_left_speed = (1 / WHEEL_RADIUS) * (linear_x + linear_y - (half_axis_separation+half_axis_length) * angular_z);
    float rear_right_speed = (1 / WHEEL_RADIUS) * (linear_x - linear_y + (half_axis_separation+half_axis_length) * angular_z);
    // Map the speed to the PWM range
    // adaptado do t2, mas considerando cada motor
    uint16_t front_left_pwm = (uint16_t) fmap(fabs(front_left_speed), 0.0, 1.0, motor_setup.PWM_MOTOR_MIN, motor_setup.PWM_MOTOR_MAX);
    uint16_t front_right_pwm = (uint16_t) fmap(fabs(front_right_speed), 0.0, 1.0, motor_setup.PWM_MOTOR_MIN, motor_setup.PWM_MOTOR_MAX);
    uint16_t rear_left_pwm = (uint16_t) fmap(fabs(rear_left_speed), 0.0, 1.0, motor_setup.PWM_MOTOR_MIN, motor_setup.PWM_MOTOR_MAX);
    uint16_t rear_right_pwm = (uint16_t) fmap(fabs(rear_right_speed), 0.0, 1.0, motor_setup.PWM_MOTOR_MIN, motor_setup.PWM_MOTOR_MAX);
    
     // Motor front - JS
    // Set the direction
    // adaptado do t2, mas considerando cada motor front
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_LEFT_FORWARD, front_left_pwm * (front_left_speed > 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_LEFT_BACKWARD, front_left_pwm * (front_left_speed < 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_RIGHT_FORWARD, front_right_pwm * (front_right_speed > 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_RIGHT_BACKWARD, front_right_pwm * (front_right_speed < 0));
    // Update the PWM channels
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_LEFT_FORWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_LEFT_BACKWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_RIGHT_FORWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.front_PWM_RIGHT_BACKWARD);
    // get direction
    //int dir = (left_speed > 0) ? 1 : -1;
 
 // Motor rear - JS
    // Set the direction
    
    // Padrão
    //Motor Rear
// adaptado do t1, mas considerando cada motor rear
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_LEFT_FORWARD, rear_left_pwm  * (rear_left_speed > 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_LEFT_BACKWARD, rear_left_pwm  * (rear_left_speed < 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_RIGHT_FORWARD, rear_right_pwm  * (rear_right_speed > 0));
    ledc_set_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_RIGHT_BACKWARD, rear_right_pwm  * (rear_right_speed < 0));

    // Update the PWM channels
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_LEFT_FORWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_LEFT_BACKWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_RIGHT_FORWARD);
    ledc_update_duty(motor_setup.PWM_MODE, motor_setup.rear_PWM_RIGHT_BACKWARD);
    // get direction
    //int dir = (left_speed > 0) ? 1 : -1;

    //JS - comando para imprimir, retirado do fox_t1
    // imprime considerando cada motor
    // printf("%d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %d, %f, %f, %f, %f\n", front_left_pwm, front_left_speed > 0, front_left_speed < 0, front_right_pwm, front_right_speed > 0, front_right_speed < 0, rear_left_pwm, rear_left_speed > 0, rear_left_speed < 0, rear_right_pwm, rear_right_speed > 0, rear_right_speed < 0 ,front_left_speed, front_right_speed, rear_left_speed, rear_right_speed);


}

// fmap function
float fmap(float val, float in_min, float in_max, float out_min, float out_max) {
    return (val - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}
