#pragma once

// Constants
#define SLEEP_TIME 10
#define PI 3.14159265358979323846

// struct Motor Setup
typedef struct {
    int LED_BUILTIN;
    //Motor front - JS
    int front_PIN_LEFT_FORWARD;
    int front_PIN_LEFT_BACKWARD;
    int front_PIN_RIGHT_FORWARD;
    int front_PIN_RIGHT_BACKWARD;
    int front_PWM_LEFT_FORWARD;
    int front_PWM_LEFT_BACKWARD;
    int front_PWM_RIGHT_FORWARD;
    int front_PWM_RIGHT_BACKWARD;
    //Motor rear - JS
    int rear_PIN_LEFT_FORWARD;
    int rear_PIN_LEFT_BACKWARD;
    int rear_PIN_RIGHT_FORWARD;
    int rear_PIN_RIGHT_BACKWARD;
    int rear_PWM_LEFT_FORWARD;
    int rear_PWM_LEFT_BACKWARD;
    int rear_PWM_RIGHT_FORWARD;
    int rear_PWM_RIGHT_BACKWARD;
        
    int PWM_FREQUENCY;
    char PWM_RESOLUTION;
    char PWM_TIMER;
    char PWM_MODE;
    int PWM_MOTOR_MIN;
    int PWM_MOTOR_MAX;
} motor_setup_t;

// linear and angular variables
// adicionado linear y
float linear_x;
float linear_y;
float angular_z;

/*Function prototypes*/
float fmap(float val, float in_min, float in_max, float out_min, float out_max);
void InitMotorDriver(motor_setup_t motor_setup);
void SetMotorSpeed(float linear_x, float linear_y, float angular_z);